@extends('layouts.structure')

@section('content')
    <!--begin home section -->
    <section class="home-section" id="home">
      <div class="home-section-overlay"></div>

      <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-8-->
          <div class="col-md-8 mx-auto padding-top-50">
          <h1>Contact Me</h1>
            <p>Do you have a question, suggestion, or just want to say, <br>“Thank you” Let me know</p>
          </div>
          <!--end col-md-8-->
        </div>
        <!--end row -->
      </div>
      <!--end container -->
    </section>
    <!--end home section -->

    <!--begin section-grey -->
    <section class="section-grey section-top-border">
      <div class="container">
        <div class="row">
          
        </div>
      </div>
    </section>
    <!--end section-grey -->

@endsection