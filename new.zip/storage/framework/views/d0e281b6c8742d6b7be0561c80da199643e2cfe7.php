<?php $__env->startSection('content'); ?>
        <!-- Main Container -->
        <main id="main-container">

            <!-- Hero -->
            <div class="bg-body-light">
                <div class="content content-full">
                    <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                        <h1 class="flex-sm-fill h3 my-2">
                            Add Symptoms
                        </h1>
                        <!--<nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                            <ol class="breadcrumb breadcrumb-alt">
                                <li class="breadcrumb-item">Generic</li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a class="link-fx" href="">Blank (Block)</a>
                                </li>
                            </ol>
                        </nav><!-->
                    </div>
                </div>
            </div>
            <!-- END Hero -->

            <!-- Page Content -->
            <div class="content">
                <!-- Your Block -->
                <div class="block">
                    <div class="block-content">
                        <?php if(count($errors) > 0): ?>

                        <div class="alert alert-danger">

                            <span class="text-danger"><strong >Whoops!</strong> There were some problems with your input.</span><br><br>

                            <ul>

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="text-danger"><?php echo e($message); ?></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                        </div>


                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-12">
                                <form method="post" action=" <?php echo e(route('manage-symptoms.store')); ?> ">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row field_wrapper">
                                        

                                        <div class="col-md-4 mb-3">
                                            <label for="validationServer02">Select Category</label>
                                            <select class="form-control is-valid" name="category" required id="validationServer02">
                                                <option selected disabled>Please Select Category</option>
                                                <option value="Apperance Change" >Apperance Change</option>
                                                <option value="Gynecological Pain">Gynecological Pain</option>
                                                <option value="Mental and Emotional Health">Mental and Emotional Health</option>
                                                <option value="Physiological">Physiological</option>
                                            </select>
                                        
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="validationServer01">Symptoms Name</label>
                                            <input type="text" name="options[]" class="form-control is-valid" required  id="validationServer01" placeholder="Type Symptoms Here">
                                        
                                        </div>

                                    </div>                                   

                                    

                                    <button type="button" id="addOptions" class="btn btn-primary">Add </button><br><br>
                                    
                                    
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </form>
                            </div>
                        </div><br>
                      <div class="col-sm-12">
                            <div class="">
                                <table class="table table-condensed table-responsive table-striped table-vcenter js-dataTable-buttons dataTable no-footer" id="DataTables_Table_3" role="grid" aria-describedby="DataTables_Table_3_info">
                                    <thead>
                                        <tr role="row">
                                            <th class="text-center sorting_asc" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending">ID</th>
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Symptoms: activate to sort column ascending">Symptoms</th>
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Category: activate to sort column ascending">Category</th>
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending">Action</th>
<!-- 
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Country: activate to sort column ascending">Gynecological Issue</th>
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Country: activate to sort column ascending">Mental & Emotional Health</th>
                                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending">Other</th> -->
                                    </thead>
                                    <tbody>
                                    <?php if(count($symptomsCategories) > 0): ?>
                                        
                                        <?php $__currentLoopData = $symptomsCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <tr role="row" class="odd">
                                                <td class="text-center font-size-sm sorting_1"> <?php echo e($loop->iteration); ?> </td>
                                                
                                                <td class="font-w600 font-size-sm">
                                                <?php $__currentLoopData = $symptom->symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($value->symptoms_name.','); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                
                                                
                                                <td class="font-w600 font-size-sm">
                                                    <?php echo e($symptom->category); ?>

                                                </td>
                                                
                                                <td class="">
                                                    <div class="btn-group">
                                                        <button class="btn btn-primary"><span class="fa fa-edit"></span></button>
                                                        <form action="<?php echo e(route('manage-symptoms.destroy', $symptom->id )); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input name="_method" type="hidden" value="DELETE">
                                                            <button type="submit" class="btn btn-danger"><span class="fa fa-trash"></span></button>
                                                        </form>
                                                    </div>
                                                    
                                                </td>
                                                
                                            </tr>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                </div>
                <!-- END Your Block -->
            </div>
            <!-- END Page Content -->

        </main>
        <!-- END Main Container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/admin/manage_symptoms.blade.php ENDPATH**/ ?>