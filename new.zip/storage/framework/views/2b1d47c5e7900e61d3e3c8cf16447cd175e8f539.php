<?php $__env->startSection('content'); ?>

        <!-- Main Container -->
        <main id="main-container">

            <!-- Hero -->
            <div class="bg-body-light">
                <div class="content content-full">
                    <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                        <h1 class="flex-sm-fill h3 my-2">
                            All Blog Post
                        </h1>
                        <!--<nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                            <ol class="breadcrumb breadcrumb-alt">
                                <li class="breadcrumb-item">Generic</li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a class="link-fx" href="">Blank (Block)</a>
                                </li>
                            </ol>
                        </nav><!-->
                    </div>
                </div>
            </div>
            <!-- END Hero -->

            <!-- Page Content -->
            <div class="content">
                <!-- Your Block -->
                <div class="block">
                <?php if(count($errors) > 0): ?>

                    <div class="alert alert-danger">

                        <span class="text-danger"><strong >Whoops!</strong> There were some problems with your input.</span><br><br>

                        <ul>

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="text-danger"><?php echo e($message); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </div>


                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="block-header">
                        <h3 class="block-title">
                            Add Blog Category
                        </h3>
                        </div>
                    <div class="block-content">
                      <form action="be_forms_elements.html" method="POST" enctype="multipart/form-data" onsubmit="return false;">
                              <div class="row">

                                  <div class="col-sm-12">
                                    <table class="table table-condensed table-responsive table-striped table-vcenter js-dataTable-buttons dataTable no-footer" id="DataTables_Table_3" role="grid" aria-describedby="DataTables_Table_3_info">
                                              <thead>
                                                  <tr role="row">
                                                    <th class="text-center sorting_asc" style="width: 80px;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending">
                                                    </th>
                                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Username: activate to sort column ascending">Title</th>
                                                    <th class="sorting" style="width: 30%;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending">Author</th>
                                                    <th class="sorting" style="width: 30%;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Country: activate to sort column ascending">Featured Image</th>


                                              </thead>
                                              <tbody>
                                            <?php if(count($allPost) > 0 ): ?>
                                                <?php for($i=1;$i>1;): ?>
                                                <?php endfor; ?>
                                                <?php $__currentLoopData = $allPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row" class="odd">
                                                    <td class="text-center font-size-sm sorting_1"><?php echo e($i++); ?></td>
                                                    <td class="font-w600 font-size-sm">
                                                        <?php echo e($post->title); ?>

                                                    </td>
                                                    <td class=" font-size-sm">
                                                        <?php echo e($post->author); ?>

                                                    </td>
                                                    <td class="">
                                                        <?php echo e($post->filename); ?>

                                                    </td>

                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>

                                            <?php endif; ?>
                                          </table>
                                        </div>


                                  </div>
                              </div>
                          </form>
                    </div>


                </div>
                <!-- END Your Block -->
            </div>
            <!-- END Page Content -->

        </main>
        <!-- END Main Container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/admin/blog_all_post.blade.php ENDPATH**/ ?>