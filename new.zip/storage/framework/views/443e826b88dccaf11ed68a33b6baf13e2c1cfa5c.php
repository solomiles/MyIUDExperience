<?php $__env->startSection('content'); ?>

    <!--begin home section -->
    <section class="home-section" id="home">
      <div class="home-section-overlay"></div>

      <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-8-->
          <div class="col-md-8 mx-auto padding-top-50">
            <h1>Forum Topics</h1>
            <p>
                Choose or Create a Topic and lets discuss
            </p>
          </div>
          <!--end col-md-8-->
        </div>
        <!--end row -->
      </div>
      <!--end container -->
    </section>
    <!--end home section -->

    <!--begin section-grey -->
    <section class="section-grey section-top-border">
      <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-12 -->
          <div class="col-md-12">
          <div class="content content-full">
          <div class="bg-body-light"></div>
          <?php if(count($errors) > 0): ?>

                    <div class="alert alert-danger">

                        <span class="text-danger"><strong >Whoops!</strong> There were some problems with your input.</span><br><br>

                        <ul>

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="text-danger"><?php echo e($message); ?></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </div>
                    

                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                            <h1 class="flex-sm-fill h3 my-2">
                                Explore a category
                            </h1>
                            <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                                <ol class="breadcrumb breadcrumb-alt">
                                    <li class="breadcrumb-item">
                                        <a class="link-fx text-dark" href=" <?php echo e(route('forum.index')); ?> ">Forum</a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a class="link-fx" href=" <?php echo e(route('forum.index')); ?> ">Topics</a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>

                    <div class="row">
                        
                        
                        <div id="newForm" style="display: none" class="col-md-12">
                            <div class="col-md-6"> 
                            <!-- {{ route('support.store') }} -->
                                <form method="post" action=" <?php echo e(route('forum.store')); ?> " role="form">
                                    <?php echo csrf_field(); ?>
                                    <!-- <input value="PATCH" name="_method" type="hidden" > -->
                                    
                                    <div class="form-group">
                                        <label for="topic" >Topic</label>

                                        <input placeholder="Type Your Topic Here" class="<?php if ($errors->has('topic')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('topic'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control border-input" type="text" required name="topic">
                                        <?php if ($errors->has('topic')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('topic'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?> </strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>

                                    <!-- <div class="form-group">
                                        <label for="issue-description" >Issue Description</label>

                                        <textarea placeholder="Please tell us briefly about the issue" class="form-control border-input" type="text" required rows="5" name="description"></textarea>
                                    </div> -->

                                    <div class="form-group">
                                        

                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        
                    </div><br><hr>
             
                   
                        <div class="block-content">
                        <div class="block">
                        <div class="block-header block-header-default">
                            <h3 class="block-title">Topics</h3>
                            <div class="block-options">
                                
                                <!-- <div class="col-md-6" style="margin-bottom: 25px;"> -->
                                    <button id="newButton" type="button" class="btn btn-info "><i class="fa fa-plus mr-1"></i> New Topic</button>
                                <!-- </div> -->
                                
                            </div>
                        </div>
                            <!-- Topics -->
                            <table class="table table-striped table-borderless table-vcenter">
                                <thead class="border-bottom">
                                    <tr>
                                        <th colspan="2">Welcome</th>
                                        <th class="d-none d-md-table-cell text-center" style="width: 100px;"></th>
                                        <th class="d-none d-md-table-cell text-center" style="width: 100px;">Comments</th>
                                        
                                        <th class="d-none d-md-table-cell" style="width: 200px;">Last Post</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php if($topics->count() > 0): ?>
                                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center" style="width: 40px;">
                                                <i class="si si-pin"></i>
                                            </td>
                                            <td>
                                                <a class="font-w600" href=" <?php echo e(route('forum-discussion.show', $topic->slug)); ?> "> <?php echo e($topic->topic); ?> </a>
                                                <div class="font-size-sm text-muted mt-1">
                                                    created by<a href="#"> <?php echo e($topic->user->username); ?>  </a>  on  <em> <?php echo e(date('M d, Y', strtotime($topic->created_at))); ?> </em>
                                                </div>
                                            </td>
                                            <td class="d-none d-md-table-cell text-center">
                                                <!-- <a class="font-w600" href="javascript:void(0)">278</a> -->
                                            </td>
                                            
                                            
                                            <td class="d-none d-md-table-cell text-center">
                                                <?php if( count($topic->forumcomments) > 0): ?>
                                                <a class="font-w600" href="javascript:void(0)"> <?php echo e(count($topic->forumcomments)); ?> </a>
                                                <?php else: ?>
                                                <a class="font-w600" href="javascript:void(0)"> 0 </a>
                                                <?php endif; ?>
                                            </td>
                                            <?php $__currentLoopData = $topic->forumcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($loop->last): ?>
                                            <td class="d-none d-md-table-cell">
                                                <span class="font-size-sm">by <a href="#"> <?php echo e($lastpost->user->username); ?> </a><br>on <em><?php echo e(date('M d, Y', strtotime($lastpost->created_at))); ?></em></span>
                                            </td>
                                           <?php endif; ?>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7">No topics yet, create a new topic!</td>
                                    </tr>
                                        
                                <?php endif; ?>
                                    
                                   
                                </tbody>
                            </table>
                            <!-- END Topics -->

                            <!-- Pagination -->
                            <?php echo e($topics->links()); ?>

                            <!-- END Pagination -->
                        </div>
                    </div>     
            </div>
        </div>
</div>
      <!--end container -->
    </section>
    <!--end section-grey -->

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/forum/forum_topics.blade.php ENDPATH**/ ?>