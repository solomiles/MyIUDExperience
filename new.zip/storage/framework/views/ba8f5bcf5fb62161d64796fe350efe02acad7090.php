<?php $__env->startSection('content'); ?>
    <!--end header -->

    <!--begin home section -->
    <section class="home-section">
      <div class="home-section-overlay"></div>

      <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-8-->
          <div class="col-md-8 mx-auto padding-top-50">
            <h4>Symptoms Tracker</h4>

            <!-- <p>
              Explore our free Personalized Tools to Track, Monitor, and Manage
              your cycles
            </p> -->

          </div>
          <!--end col-md-8-->
        </div>
        <!--end row -->
      </div>
      <!--end container -->
    </section>
    <!--end home section -->

    <!--begin section-grey -->
    <section class="section-grey section-top-border">
      <!--begin container -->
      <div class="container">
        <?php if(count($errors) > 0): ?>

          <div class="alert alert-danger">

            <span class="text-danger"><strong >Whoops!</strong> There were some problems with your input.</span><br><br>

            <ul>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="text-danger"><?php echo e($message); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

          </div>


        <?php endif; ?>
        <?php if(Session::has('success')): ?>
          <div class="alert alert-success">
              <?php echo e(Session::get('success')); ?>

          </div>
        <?php endif; ?>
        <h5>Welcome <?php echo e(auth::user()->username); ?>,</h5><br>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <!--begin row -->
        <h5>View Daily Symptoms Chart</h5>
          <div class="row">
            <div class="col-md-12">
              <!-- <div class="col-lg-8 col-sm-6"> -->

                <form action=" <?php echo e(action('SymptomsTrackerController@dailyGraph')); ?> " method="POST" role="form" >
                <?php echo csrf_field(); ?>
                  <div class="row">
                    <!-- <div class="col-md-12"> -->
                      <!-- <div class="form-group"> -->

                        <div class="col-md-3">
                          <select class="form-control" data-placeholder="--Select--" name="trackedDate" required>
                          <?php if( count($trackedDate) > 0): ?>
                            <option selected disabled>--Select--</option>
                            <?php $__currentLoopData = $trackedDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($date->created_at); ?>"><?php echo e(date('M d, Y', strtotime($date->created_at))); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <option disabled >No Dates Found</option>
                          <?php endif; ?>
                          </select>
                          
                        </div>
                      
                        <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                      <!-- </div> -->
                    
                  </div>
                </form>
              </div>
            <!-- </div> -->
          </div>
            <br>
          <?php if(Session::has('results')): ?>
          <div class="row">
            <div class="col-md-12">
              <div class=" col-md-8">
                <div class="table-responsive">                  
                  <table class="table table-sm table-striped table-striped table-hover">
                      <thead>
                        <th>Symptoms</th>
                        <th>Symptoms Level</th>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = Session::get('results'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        
                          <td><?php echo e($result->symptoms->symptoms_name); ?></td>
                          
                          <td> <?php if($result->symptoms_level == 0): ?>
                              <label><?php echo e('none'); ?></label>
                              <?php elseif($result->symptoms_level == 20): ?>
                                <label style="color:yellowgreen;"><?php echo e('mild'); ?></label>
                              <?php elseif($result->symptoms_level == 50): ?>
                              <label style="color:#2586ff;"><?php echo e('moderate'); ?></label>
                              <?php elseif($result->symptoms_level == 85): ?>
                              <label style="color:#f15c5c;"><?php echo e('severe'); ?></label>
                              <?php endif; ?>
                          </td>

                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <?php else: ?>
                      <div class="table-responsive">
                            <form action=" <?php echo e(route('track-symptoms.store')); ?>" role="form" method="Post">
                               <?php echo csrf_field(); ?> 
                               <input value=" <?php echo e(auth::user()->id); ?> " name="user_id" type="hidden">
                               <?php if(count($symptoms) > 0): ?>
                               <?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <table class="table table-striped table-striped table-vcenter">
                                    <tbody>
                                            <h5> <?php echo e($symptom->category); ?> </h5>
                                            <?php $__currentLoopData = $symptom->symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                          <input type="hidden" name="symptoms_id[]" value=" <?php echo e($value->id); ?> ">
                                            <td>
                                                <?php echo e($value->symptoms_name); ?>

                                            </td>
                                            <td>
                                              <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio"  name="symptoms_level[].<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>1" value="0" >
                                                <label class="custom-control-label" for="<?php echo e($value->id); ?>1">
                                                    None
                                                </label>
                                              </div>
                                            </td>
                                            <td>
                                              <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" name="symptoms_level[].<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>2" value="20" >
                                                <label class="custom-control-label" for="<?php echo e($value->id); ?>2">
                                                    Mild
                                                </label>
                                              </div>
                                            </td>
                                            <td>
                                              <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" name="symptoms_level[].<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>3" value="50" >
                                                <label class="custom-control-label" for="<?php echo e($value->id); ?>3">
                                                    Moderate
                                                </label>
                                              </div>
                                            </td>
                                            <td>
                                              <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" name="symptoms_level[].<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>4" value="85" >
                                                <label class="custom-control-label" for="<?php echo e($value->id); ?>4">
                                                    Severe
                                                </label>
                                              </div>
                                            </td>
                                        </tr>

                                      
                                        <tr class="field_wrapper<?php echo e($value->id); ?>"></tr><tr></tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                          
                                <tr>
                                  <td>
                                      <div class="form-group">
                                        <label for="example-text-input">Other <?php echo e($symptom->category); ?> (Please Specify)</label>
                                        <input type="text" id="newSymptoms<?php echo e($value->id); ?>" class="form-control new_appearance" id="example-text-input" name="" placeholder="Enter Symptoms">
                                          <br><button type="button" id="addOptions.<?php echo e($value->id); ?>" class="btn btn-primary add_button_apperamce">Add</button>
                                      </div>
                                  </td>
                                </tr>
                                       
                                    </tbody>
                                </table>
                                <script>
                                    $(document).ready(function(){
                                      // for add new type button
                                      var maxField = 30; //Input fields increment limitation
                                      var addButton = $('#addOptions'); //Add button selector
                                      
                                      var wrapper = $('.field_wrapper'); //Input field wrapper
                                      // var fieldHTML = '<div class="form-check"><input class="form-check-input remove_button" type="radio" id="#" name="type" value="'+new_type+'" ><label class="form-check-label" for="example-radios-default1">'+new_type+'</label></div>';
                                      // '<div><input type="text" name="field_name[]" value=""/><a href="javascript:void(0);" class="remove_button"><img src="remove-icon.png"/></a></div>'; //New input field html 
                                      var x = 1; //Initial field counter is 1
                                      
                                      //Once add button is clicked
                                      $(addButton).click(function(){
                                          //Check maximum number of input fields

                                          var new_symptoms = $('.new_type').val();
                                          var fieldHTML = '<div class="col-md-4 mb-3"><label for="validationServer01">Option '+x+'</label><input type="text" name="options[]" class="form-control is-valid"  id="validationServer01" placeholder="Please Type In Options '+x+'"></div>';

                                          if(x < maxField ){ 
                                              x++; //Increment field counter
                                              $(wrapper).append(fieldHTML); //Add field html
                                          }
                                      });
                                      
                                      //Once remove button is clicked
                                      $(wrapper).on('click', '.remove_button', function(e){
                                          e.preventDefault();
                                          $(this).parent('div').remove(); //Remove field html
                                          x--;
                                          //Decrement field counter
                                      });
                                      // end add new type button
                                  });
                                </script>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                              <?php endif; ?>
                               
                            </div>
                            <div class="col-sm-6">
                              <div class="btn-group" role="group" aria-label="Horizontal Primary">
                                  <button type="submit" class="btn btn-primary">Submit</button>
                                  <button type="button" class="btn btn-danger">Cancel</button>
                              </div>
                            </div>
                          </form>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- END Full Table -->
<!-- </form> -->
        <!--end row -->

      <!--end container -->
    </section>
    <!--end section-grey -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/symptoms_myiud.blade.php ENDPATH**/ ?>