<?php $__env->startSection('content'); ?>
<script>
    Swal.fire({

    title: '<strong>User Demographic Information</strong>',
    type: 'success',
    html:
        'Thanks For Sharing Your Experience With Us',
    // showCloseButton: true,
    focusConfirm: false,
    confirmButtonText:
        '<a style="color:#fff;"  href="/"><i class="fa fa-thumbs-up"></i>Continue To MyIUDExperience.com</a>',
    // confirmButtonAriaLabel: 'Thumbs up, great!',
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/completedSurvey.blade.php ENDPATH**/ ?>