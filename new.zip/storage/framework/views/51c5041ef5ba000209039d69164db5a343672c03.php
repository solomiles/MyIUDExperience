<?php $__env->startSection('content'); ?>

        <!-- Main Container -->
        <main id="main-container">

            <!-- Hero -->
            <div class="bg-body-light">
                <div class="content content-full">
                    <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                        <h1 class="flex-sm-fill h3 my-2">
                            User Account
                        </h1>
                        <!--<nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                            <ol class="breadcrumb breadcrumb-alt">
                                <li class="breadcrumb-item">Generic</li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a class="link-fx" href="">Blank (Block)</a>
                                </li>
                            </ol>
                        </nav><!-->
                    </div>
                </div>
            </div>
            <!-- END Hero -->

            <!-- Page Content -->
            <div class="content">
                <!-- Your Block -->
                <div class="block">
                    <div class="block-content">
                      <div class="col-sm-12"><table class="table table-bordered table-striped table-vcenter js-dataTable-buttons dataTable no-footer" id="DataTables_Table_3" role="grid" aria-describedby="DataTables_Table_3_info">
                                  <thead>
                                      <tr role="row">
                                        <th class="text-center sorting_asc" style="width: 80px;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending">ID</th>
                                          <th class="sorting" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Username: activate to sort column ascending">Username</th>
                                            <th class="d-none d-sm-table-cell sorting" style="width: 30%;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending">Email</th>
                                              <th class="d-none d-sm-table-cell sorting" style="width: 30%;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Country: activate to sort column ascending">Country</th>
                                              <th class="d-none d-sm-table-cell sorting" style="width: 15%;" tabindex="0" aria-controls="DataTables_Table_3" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending">Action</th>
                                  </thead>
                                  <tbody>

                                  <tr role="row" class="odd">
                                          <td class="text-center font-size-sm sorting_1">1</td>
                                          <td class="font-w600 font-size-sm">
                                              Melissa Rice
                                          </td>
                                          <td class="d-none d-sm-table-cell font-size-sm">
                                              client1<em class="text-muted">@example.com</em>
                                          </td>
                                          <td class="d-none d-sm-table-cell">
                                              Spain
                                          </td>
                                          <td>
                                                <a href="#">Edit</a>
                                          </td>
                                      </tr>

                                      <tr role="row" class="even">
                                          <td class="text-center font-size-sm sorting_1">2</td>
                                          <td class="font-w600 font-size-sm">
                                              Becky2001
                                          </td>
                                          <td class="d-none d-sm-table-cell font-size-sm">
                                              client2<em class="text-muted">@example.com</em>
                                          </td>
                                          <td class="d-none d-sm-table-cell">
                                              <span class="#">Nigeria</span>
                                          </td>
                                          <td>
                                              <a href="#">Edit</a>
                                          </td>
                                      </tr>
                              </table>
                            </div>
                </div>
                <!-- END Your Block -->
            </div>
            <!-- END Page Content -->

        </main>
        <!-- END Main Container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/admin/manage_blog.blade.php ENDPATH**/ ?>