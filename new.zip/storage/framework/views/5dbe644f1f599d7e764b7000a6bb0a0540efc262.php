<?php $__env->startSection('content'); ?>

    <!--begin section-grey -->
    <section class="section-blue">
    <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-8 -->
          <div class="col-md-12">
            <p style="margin-top:70px;">Please be honest when filling this survey. 
            The survey takes less than 5 minutes. Your responses are important as 
            it will be use to help other woman make informed decision regarding the use of
            levonorgestrel-releasing intrauterine (hormonal IUD). Please let's help each other.  
            *Correlation does not imply causation but it can start a conversation.*</p>
            <h4>My Experience with Levonorgestrel-Releasing Intrauterine Device</h4><br>
            <div class="col-md-12">
                            <!-- Progress Wizard 2 -->
                            <div class="js-wizard-simple block block ">
                                <!-- Wizard Progress Bar -->
                                <div class="progress rounded-0" data-wizard="progress" style="height: 8px;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 34.3333%;" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <!-- END Wizard Progress Bar -->

                                <!-- Step Tabs -->
                                <ul class="nav nav-tabs nav-tabs-alt nav-justified" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#wizard-progress2-step1" data-toggle="tab">1. User Demographic Information</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#wizard-progress2-step2" data-toggle="tab">2. User Demographic Information</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#wizard-progress3-step3" data-toggle="tab">3. The Symptom</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#wizard-progress4-step4" data-toggle="tab">4. The Symptom</a>
                                    </li>
    
                                </ul>
                                <!-- END Step Tabs -->

                                <!-- Form -->
                                <form action="be_forms_wizard.html" method="POST">
                                    <!-- Steps Content -->
                                    <div class="block-content block-content-full tab-content px-md-5" style="min-height: 314px;">
                                        <!-- Step 1 -->
                                        <div class="tab-pane active" id="wizard-progress2-step1" role="tabpanel"><br>
                                            <div class="form-group">
                                                <label for="wizard-progress2-firstname">1. What is your age? (Please enter your true age)</label>
                                                <input class="form-control form-control-alt" type="text" id="what-is-your-age" name="wizard-progress2-firstname">
                                            </div>
                                            <div class="form-group">
                                                <label for="wizard-progress2-lastname">2. Are you White, Black or African-American, American Indian or Alaskan Native, Asian, Native Hawaiian or other Pacific islander, or some other race?</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id=""  name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">White</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1"> Black or African-American</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1"> American Indian or Alaskan Native</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">  Asian</label></div>

                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1"> Native Hawaiian or other Pacific Islander</label></div>
                                                
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">  From multiple races</label></div>
                                                
                                                <div class="form-check">
                                                Some other race (please specify)
                                                <input class="form-control form-control-alt" type="text" id="wizard-progress2-lastname" 
                                                name="wizard-progress2-lastname"></div>
                                            </div>

                                            <div class="form-group">
                                                <label for="wizard-progress2-email">3. What country are you from?</label>
                                               
                                                            <select class="form-control" id="example-select" name="example-select">
                                                            <option value="0">Select Country </option>
                                                            <option value="Afghanistan">Afghanistan</option>
                                                            <option value="Åland Islands">Åland Islands</option>
                                                            <option value="Albania">Albania</option>
                                                            <option value="Algeria">Algeria</option>
                                                            <option value="American Samoa">American Samoa</option>
                                                            <option value="Andorra">Andorra</option>
                                                            <option value="Angola">Angola</option>
                                                            <option value="Anguilla">Anguilla</option>
                                                            <option value="Antarctica">Antarctica</option>
                                                            <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                            <option value="Argentina">Argentina</option>
                                                            <option value="Armenia">Armenia</option>
                                                            <option value="Aruba">Aruba</option>
                                                            <option value="Australia">Australia</option>
                                                            <option value="Austria">Austria</option>
                                                            <option value="Azerbaijan">Azerbaijan</option>
                                                            <option value="Bahamas">Bahamas</option>
                                                            <option value="Bahrain">Bahrain</option>
                                                            <option value="Bangladesh">Bangladesh</option>
                                                            <option value="Barbados">Barbados</option>
                                                            <option value="Belarus">Belarus</option>
                                                            <option value="Belgium">Belgium</option>
                                                            <option value="Belize">Belize</option>
                                                            <option value="Benin">Benin</option>
                                                            <option value="Bermuda">Bermuda</option>
                                                            <option value="Bhutan">Bhutan</option>
                                                            <option value="Bolivia">Bolivia</option>
                                                            <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                            <option value="Botswana">Botswana</option>
                                                            <option value="Bouvet Island">Bouvet Island</option>
                                                            <option value="Brazil">Brazil</option>
                                                            <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                            <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                            <option value="Bulgaria">Bulgaria</option>
                                                            <option value="Burkina Faso">Burkina Faso</option>
                                                            <option value="Burundi">Burundi</option>
                                                            <option value="Cambodia">Cambodia</option>
                                                            <option value="Cameroon">Cameroon</option>
                                                            <option value="Canada">Canada</option>
                                                            <option value="Cape Verde">Cape Verde</option>
                                                            <option value="Cayman Islands">Cayman Islands</option>
                                                            <option value="Central African Republic">Central African Republic</option>
                                                            <option value="Chad">Chad</option>
                                                            <option value="Chile">Chile</option>
                                                            <option value="China">China</option>
                                                            <option value="Christmas Island">Christmas Island</option>
                                                            <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                            <option value="Colombia">Colombia</option>
                                                            <option value="Comoros">Comoros</option>
                                                            <option value="Congo">Congo</option>
                                                            <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                                            <option value="Cook Islands">Cook Islands</option>
                                                            <option value="Costa Rica">Costa Rica</option>
                                                            <option value="Cote D'ivoire">Cote D'ivoire</option>
                                                            <option value="Croatia">Croatia</option>
                                                            <option value="Cuba">Cuba</option>
                                                            <option value="Cyprus">Cyprus</option>
                                                            <option value="Czech Republic">Czech Republic</option>
                                                            <option value="Denmark">Denmark</option>
                                                            <option value="Djibouti">Djibouti</option>
                                                            <option value="Dominica">Dominica</option>
                                                            <option value="Dominican Republic">Dominican Republic</option>
                                                            <option value="Ecuador">Ecuador</option>
                                                            <option value="Egypt">Egypt</option>
                                                            <option value="El Salvador">El Salvador</option>
                                                            <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                            <option value="Eritrea">Eritrea</option>
                                                            <option value="Estonia">Estonia</option>
                                                            <option value="Ethiopia">Ethiopia</option>
                                                            <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                            <option value="Faroe Islands">Faroe Islands</option>
                                                            <option value="Fiji">Fiji</option>
                                                            <option value="Finland">Finland</option>
                                                            <option value="France">France</option>
                                                            <option value="French Guiana">French Guiana</option>
                                                            <option value="French Polynesia">French Polynesia</option>
                                                            <option value="French Southern Territories">French Southern Territories</option>
                                                            <option value="Gabon">Gabon</option>
                                                            <option value="Gambia">Gambia</option>
                                                            <option value="Georgia">Georgia</option>
                                                            <option value="Germany">Germany</option>
                                                            <option value="Ghana">Ghana</option>
                                                            <option value="Gibraltar">Gibraltar</option>
                                                            <option value="Greece">Greece</option>
                                                            <option value="Greenland">Greenland</option>
                                                            <option value="Grenada">Grenada</option>
                                                            <option value="Guadeloupe">Guadeloupe</option>
                                                            <option value="Guam">Guam</option>
                                                            <option value="Guatemala">Guatemala</option>
                                                            <option value="Guernsey">Guernsey</option>
                                                            <option value="Guinea">Guinea</option>
                                                            <option value="Guinea-bissau">Guinea-bissau</option>
                                                            <option value="Guyana">Guyana</option>
                                                            <option value="Haiti">Haiti</option>
                                                            <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                                            <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                                            <option value="Honduras">Honduras</option>
                                                            <option value="Hong Kong">Hong Kong</option>
                                                            <option value="Hungary">Hungary</option>
                                                            <option value="Iceland">Iceland</option>
                                                            <option value="India">India</option>
                                                            <option value="Indonesia">Indonesia</option>
                                                            <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                                            <option value="Iraq">Iraq</option>
                                                            <option value="Ireland">Ireland</option>
                                                            <option value="Isle of Man">Isle of Man</option>
                                                            <option value="Israel">Israel</option>
                                                            <option value="Italy">Italy</option>
                                                            <option value="Jamaica">Jamaica</option>
                                                            <option value="Japan">Japan</option>
                                                            <option value="Jersey">Jersey</option>
                                                            <option value="Jordan">Jordan</option>
                                                            <option value="Kazakhstan">Kazakhstan</option>
                                                            <option value="Kenya">Kenya</option>
                                                            <option value="Kiribati">Kiribati</option>
                                                            <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                            <option value="Korea, Republic of">Korea, Republic of</option>
                                                            <option value="Kuwait">Kuwait</option>
                                                            <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                            <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                            <option value="Latvia">Latvia</option>
                                                            <option value="Lebanon">Lebanon</option>
                                                            <option value="Lesotho">Lesotho</option>
                                                            <option value="Liberia">Liberia</option>
                                                            <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                            <option value="Liechtenstein">Liechtenstein</option>
                                                            <option value="Lithuania">Lithuania</option>
                                                            <option value="Luxembourg">Luxembourg</option>
                                                            <option value="Macao">Macao</option>
                                                            <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                                            <option value="Madagascar">Madagascar</option>
                                                            <option value="Malawi">Malawi</option>
                                                            <option value="Malaysia">Malaysia</option>
                                                            <option value="Maldives">Maldives</option>
                                                            <option value="Mali">Mali</option>
                                                            <option value="Malta">Malta</option>
                                                            <option value="Marshall Islands">Marshall Islands</option>
                                                            <option value="Martinique">Martinique</option>
                                                            <option value="Mauritania">Mauritania</option>
                                                            <option value="Mauritius">Mauritius</option>
                                                            <option value="Mayotte">Mayotte</option>
                                                            <option value="Mexico">Mexico</option>
                                                            <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                            <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                            <option value="Monaco">Monaco</option>
                                                            <option value="Mongolia">Mongolia</option>
                                                            <option value="Montenegro">Montenegro</option>
                                                            <option value="Montserrat">Montserrat</option>
                                                            <option value="Morocco">Morocco</option>
                                                            <option value="Mozambique">Mozambique</option>
                                                            <option value="Myanmar">Myanmar</option>
                                                            <option value="Namibia">Namibia</option>
                                                            <option value="Nauru">Nauru</option>
                                                            <option value="Nepal">Nepal</option>
                                                            <option value="Netherlands">Netherlands</option>
                                                            <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                            <option value="New Caledonia">New Caledonia</option>
                                                            <option value="New Zealand">New Zealand</option>
                                                            <option value="Nicaragua">Nicaragua</option>
                                                            <option value="Niger">Niger</option>
                                                            <option value="Nigeria">Nigeria</option>
                                                            <option value="Niue">Niue</option>
                                                            <option value="Norfolk Island">Norfolk Island</option>
                                                            <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                            <option value="Norway">Norway</option>
                                                            <option value="Oman">Oman</option>
                                                            <option value="Pakistan">Pakistan</option>
                                                            <option value="Palau">Palau</option>
                                                            <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                                            <option value="Panama">Panama</option>
                                                            <option value="Papua New Guinea">Papua New Guinea</option>
                                                            <option value="Paraguay">Paraguay</option>
                                                            <option value="Peru">Peru</option>
                                                            <option value="Philippines">Philippines</option>
                                                            <option value="Pitcairn">Pitcairn</option>
                                                            <option value="Poland">Poland</option>
                                                            <option value="Portugal">Portugal</option>
                                                            <option value="Puerto Rico">Puerto Rico</option>
                                                            <option value="Qatar">Qatar</option>
                                                            <option value="Reunion">Reunion</option>
                                                            <option value="Romania">Romania</option>
                                                            <option value="Russian Federation">Russian Federation</option>
                                                            <option value="Rwanda">Rwanda</option>
                                                            <option value="Saint Helena">Saint Helena</option>
                                                            <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                            <option value="Saint Lucia">Saint Lucia</option>
                                                            <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                            <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                                            <option value="Samoa">Samoa</option>
                                                            <option value="San Marino">San Marino</option>
                                                            <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                            <option value="Saudi Arabia">Saudi Arabia</option>
                                                            <option value="Senegal">Senegal</option>
                                                            <option value="Serbia">Serbia</option>
                                                            <option value="Seychelles">Seychelles</option>
                                                            <option value="Sierra Leone">Sierra Leone</option>
                                                            <option value="Singapore">Singapore</option>
                                                            <option value="Slovakia">Slovakia</option>
                                                            <option value="Slovenia">Slovenia</option>
                                                            <option value="Solomon Islands">Solomon Islands</option>
                                                            <option value="Somalia">Somalia</option>
                                                            <option value="South Africa">South Africa</option>
                                                            <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                                            <option value="Spain">Spain</option>
                                                            <option value="Sri Lanka">Sri Lanka</option>
                                                            <option value="Sudan">Sudan</option>
                                                            <option value="Suriname">Suriname</option>
                                                            <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                            <option value="Swaziland">Swaziland</option>
                                                            <option value="Sweden">Sweden</option>
                                                            <option value="Switzerland">Switzerland</option>
                                                            <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                            <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                                            <option value="Tajikistan">Tajikistan</option>
                                                            <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                            <option value="Thailand">Thailand</option>
                                                            <option value="Timor-leste">Timor-leste</option>
                                                            <option value="Togo">Togo</option>
                                                            <option value="Tokelau">Tokelau</option>
                                                            <option value="Tonga">Tonga</option>
                                                            <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                            <option value="Tunisia">Tunisia</option>
                                                            <option value="Turkey">Turkey</option>
                                                            <option value="Turkmenistan">Turkmenistan</option>
                                                            <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                            <option value="Tuvalu">Tuvalu</option>
                                                            <option value="Uganda">Uganda</option>
                                                            <option value="Ukraine">Ukraine</option>
                                                            <option value="United Arab Emirates">United Arab Emirates</option>
                                                            <option value="United Kingdom">United Kingdom</option>
                                                            <option value="United States">United States</option>
                                                            <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                            <option value="Uruguay">Uruguay</option>
                                                            <option value="Uzbekistan">Uzbekistan</option>
                                                            <option value="Vanuatu">Vanuatu</option>
                                                            <option value="Venezuela">Venezuela</option>
                                                            <option value="Viet Nam">Viet Nam</option>
                                                            <option value="Virgin Islands, British">Virgin Islands, British</option>
                                                            <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                                            <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                            <option value="Western Sahara">Western Sahara</option>
                                                            <option value="Yemen">Yemen</option>
                                                            <option value="Zambia">Zambia</option>
                                                            <option value="Zimbabwe">Zimbabwe</option>
                                                        </select>
                                                    
                                            </div>

                                            <div class="form-group">
                                                <label for="wizard-progress2-lastname">4. Have you ever used a levonorgestrel-releasing intrauterine device (IUD)?</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id=""  name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Yes</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1"> No</label></div>
                                            </div>
                                         </div>

                                            
                                        <!-- END Step 1 -->

                                        <!-- Step 2 -->
                                        <div class="tab-pane" id="wizard-progress2-step2" role="tabpanel">
                                        <br>
                                             <div class="form-group">
                                                <label for="wizard-progress2-firstname"> 5. At what age did you start using IUD?</label>
                                                <input class="form-control form-control-alt" type="text" id="" name="">
                                            </div>

                                            <div class="form-group">
                                                <label for="wizard-progress2-lastname">6. What other contraceptive methods have you used prior to using IUD?</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id=""  name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Pills</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Intrauterine device (IUD)</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Implants</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Contraceptive Patch</label></div>

                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Vaginal ring</label></div>
                                                
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Condoms, sponges, diaphragms, cervical caps</label></div>
                                                
                                                <div class="form-check">
                                                Some other race (please specify)
                                                <input class="form-control form-control-alt" type="text" id="wizard-progress2-lastname" 
                                                name="wizard-progress2-lastname"></div>
                                            </div>
                                            <div class="form-group">
                                                <label for="wizard-progress2-lastname">7. Are you currently using  a levonorgestrel-releasing IUD?</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id=""  name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">Yes</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1"> No</label></div>
                                                 </div>

                                                 <div class="form-group">
                                                <label for="wizard-progress2-lastname">8. How long have you been using levonorgestrel-releasing IUD?</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id=""  name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">1-6 months</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">6-12months</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">1-2 years</label></div>

                                                 <div class="form-check">
                                                 <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">2-3 years</label></div>

                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">3-4 years</label></div>
                                                
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" id="" name="" value="option1">
                                                <label class="form-check-label" for="example-radios-default1">4-5 years</label></div>
                                                </div>
                                                <div class="form-group">
                                                <label for="wizard-progress2-firstname"> 9. How long has it been since you last used an IUD? (Please specify in months or years)</label>
                                                <input class="form-control form-control-alt" type="text" id="" name="">
                                            </div>
                                        </div>
                                        <!-- END Step 2 -->

                                        <!-- Step 3 -->
                                        <div class="tab-pane" id="wizard-progress3-step3" role="tabpanel">
                                            <div class="form-group">
                                                <label for="wizard-simple2-location">Location</label>
                                                <input class="form-control form-control-alt" type="text" id="wizard-progress2-location" name="wizard-simple2-location">
                                            </div>
                                            <div class="form-group">
                                                <label for="wizard-progress2-skills">Skills</label>
                                                <select class="form-control form-control-alt" id="wizard-progress2-skills" name="wizard-progress2-skills">
                                                    <option value="">Please select your best skill</option>
                                                    <option value="1">Photoshop</option>
                                                    <option value="2">HTML</option>
                                                    <option value="3">CSS</option>
                                                    <option value="4">JavaScript</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <div class="custom-control custom-checkbox custom-control-primary">
                                                    <input type="checkbox" class="custom-control-input" id="wizard-progress2-terms" name="wizard-progress2-terms">
                                                    <label class="custom-control-label" for="wizard-progress2-terms">Agree with the terms</label>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END Step 3 -->

                                         <!-- Step 4 -->
                                        <div class="tab-pane" id="wizard-progress4-step4" role="tabpanel">
                                            <div class="form-group">
                                                <label for="wizard-simple2-location">Location</label>
                                                <input class="form-control form-control-alt" type="text" id="wizard-progress2-location" name="wizard-simple2-location">
                                            </div>
                                            <div class="form-group">
                                                <label for="wizard-progress2-skills">Skills</label>
                                                <select class="form-control form-control-alt" id="wizard-progress2-skills" name="wizard-progress2-skills">
                                                    <option value="">Please select your best skill</option>
                                                    <option value="1">Photoshop</option>
                                                    <option value="2">HTML</option>
                                                    <option value="3">CSS</option>
                                                    <option value="4">JavaScript</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <div class="custom-control custom-checkbox custom-control-primary">
                                                    <input type="checkbox" class="custom-control-input" id="wizard-progress2-terms" name="wizard-progress2-terms">
                                                    <label class="custom-control-label" for="wizard-progress2-terms">Agree with the terms</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END Steps Content -->

                                    <!-- Steps Navigation -->
                                    <div class="block-content block-content-sm block-content-full bg-body-light rounded-bottom">
                                        <div class="row">
                                            <div class="col-6">
                                                <button type="button" class="btn btn-secondary disabled" data-wizard="prev">
                                                    <i class="fa fa-angle-left mr-1"></i> Previous
                                                </button>
                                            </div>
                                            <div class="col-6 text-right">
                                                <button type="button" class="btn btn-secondary" data-wizard="next">
                                                    Next <i class="fa fa-angle-right ml-1"></i>
                                                </button>
                                                <button type="submit" class="btn btn-primary d-none" data-wizard="finish">
                                                    <i class="fa fa-check mr-1"></i> Submit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END Steps Navigation -->
                                </form>
                                <!-- END Form -->
                            </div>
                            <!-- END Progress Wizard 2 -->
                        </div>
        </section>
        </div>
        </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/survey_form_myiud.blade.php ENDPATH**/ ?>