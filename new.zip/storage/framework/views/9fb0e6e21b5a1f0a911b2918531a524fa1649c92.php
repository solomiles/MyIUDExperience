<?php $__env->startSection('content'); ?>

    <!--begin home section -->
    <section class="home-section" id="home">
      <div class="home-section-overlay"></div>

      <!--begin container -->
      <div class="container">
        <!--begin row -->
        <div class="row">
          <!--begin col-md-8-->
          <div class="col-md-8 mx-auto padding-top-50">
            <h1>BLOG</h1>

            <p>
              The latest stories only for you.
              Feel free to explore and read.
            </p>
          </div>
          <!--end col-md-8-->
        </div>
        <!--end row -->
      </div>
      <!--end container -->
    </section>
    <!--end home section -->
         
    <!--begin blog -->
    <section class="section-grey">
      <!--begin container-->
      <div class="container">
        <!--begin row-->
        <div class="row">
          <div class="content content-boxed">
                    <div class="row">
                        <!-- Story -->
                        <?php if(count($blogPosts) > 0): ?>
                        <?php $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 js-appear-enabled animated fadeIn" data-toggle="appear" data-offset="50" data-class="animated fadeIn">
                                <a class="block block-link-pop" href=" <?php echo e(route('blog-post.show',$post->slug)); ?> ">
                                    <img class="img-fluid" src="<?php echo e(asset('storage/'.$post->filename.'/'.$post->filename)); ?>" alt="<?php echo e($post->filename); ?>">
                                    <div class="block-content">
                                        <h4 class="mb-1"> <?php echo e($post->title); ?> </h4>
                                        <p class="font-size-sm">
                                            <span class="text-primary"><?php echo e($post->author); ?></span> <?php echo e(date('M d, Y', strtotime( $post->created_at))); ?></em>
                                        </p>
                                        <p class="font-size-sm">
                                            
                                        </p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <!-- END Story -->

                        
                        <!-- END Story -->

                    </div>

                    <!-- Pagination -->
                    <!-- Pagination -->
                    <?php echo e($blogPosts->links()); ?>

                    <!-- END Pagination -->
                </div>
          </div>
          <!--end col-md-12-->
        </div>
        <!--end row-->
    </section>
    <!--end blog -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MYIUDl\resources\views/blog.blade.php ENDPATH**/ ?>